package airline.model;

public class Flight {
    protected int flightId;
    protected String source, destination, time;
    protected double price;
    protected int seats;

    public Flight(int flightId, String source, String destination,
                  String time, double price, int seats) {
        this.flightId = flightId;
        this.source = source;
        this.destination = destination;
        this.time = time;
        this.price = price;
        this.seats = seats;
    }
}