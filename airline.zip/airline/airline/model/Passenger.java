package airline.model;

public class Passenger {
    protected int id;
    protected String name;

    public Passenger(int id, String name) {
        this.id = id;
        this.name = name;
    }
}