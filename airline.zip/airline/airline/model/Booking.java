package airline.model;

public class Booking extends Passenger {

    private int bookingId;
    private int flightId;

    public Booking(int bookingId, int id, String name, int flightId) {
        super(id, name);
        this.bookingId = bookingId;
        this.flightId = flightId;
    }
}