package airline.utils;

import java.io.*;

public class PassengerFileHandler extends Thread {

    String data;

    public PassengerFileHandler(String data) {
        this.data = data;
    }

    @Override
    public void run() {

        try {

            FileWriter fw = new FileWriter("passengers.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(data);
            bw.newLine();

            bw.close();
            fw.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // ================= DELETE PASSENGER =================
    public static void deletePassenger(int pid) {

        try {

            File input = new File("passengers.txt");
            File temp = new File("temp.txt");

            // if file doesn't exist
            if (!input.exists()) {
                System.out.println("Passenger file not found!");
                return;
            }

            BufferedReader br = new BufferedReader(new FileReader(input));
            BufferedWriter bw = new BufferedWriter(new FileWriter(temp));

            String line;

            while ((line = br.readLine()) != null) {

                // SAFE MATCH (prevents partial ID issues like 12 matching 120)
                if (!line.startsWith("Passenger ID: " + pid + " ")) {
                    bw.write(line);
                    bw.newLine();
                }
            }

            br.close();
            bw.close();

            // delete old file and rename temp
            if (input.delete()) {
                temp.renameTo(input);
            } else {
                System.out.println("❌ Could not delete original file!");
            }

        } catch (Exception e) {
            System.out.println("❌ Delete Passenger Error: " + e.getMessage());
        }
    }
}