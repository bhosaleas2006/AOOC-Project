package airline.utils;

import java.io.FileWriter;
import java.io.PrintWriter;

public class UserFileHandler extends Thread {

    private String data;

    public UserFileHandler(String data) {
        this.data = data;
    }

    @Override
    public void run() {

        try {

            FileWriter fw = new FileWriter("users.txt", true);

            PrintWriter pw = new PrintWriter(fw);

            pw.println(data);

            pw.close();
            fw.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}