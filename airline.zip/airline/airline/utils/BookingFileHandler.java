package airline.utils;

import java.io.*;

public class BookingFileHandler extends Thread {

    String data;

    public BookingFileHandler(String data) {
        this.data = data;
    }

    public void run() {

        try {

            FileWriter fw = new FileWriter("bookings.txt", true);

            fw.write(data + "\n");

            fw.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // DELETE BOOKING FROM FILE
    public static void deleteBooking(int bookingId) {

        try {

            File input = new File("bookings.txt");
            File temp = new File("temp.txt");

            BufferedReader br = new BufferedReader(new FileReader(input));
            BufferedWriter bw = new BufferedWriter(new FileWriter(temp));

            String line;

            while ((line = br.readLine()) != null) {

                if (!line.contains("Booking ID: " + bookingId)) {
                    bw.write(line);
                    bw.newLine();
                }
            }

            br.close();
            bw.close();

            input.delete();
            temp.renameTo(input);

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}