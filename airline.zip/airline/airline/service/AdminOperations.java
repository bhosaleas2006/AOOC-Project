package airline.service;

public interface AdminOperations {

    void addFlight();
    void updateFlight();
    void deleteFlight();
    void viewFlights();

    void viewPassengerBookings();
    void searchPassenger();

    void viewBookings();
    void cancelBooking();

    void reports();
}