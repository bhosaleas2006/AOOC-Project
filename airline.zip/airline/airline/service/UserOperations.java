package airline.service;

public interface UserOperations {

    void register();
    void login();

    void searchFlights();
    void viewFlights();

    void bookTicket();
    void cancelTicket();
    void viewBooking();
}