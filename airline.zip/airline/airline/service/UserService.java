package airline.service;

import airline.db.DBSetup;
import airline.utils.BookingFileHandler;
import airline.utils.PassengerFileHandler;
import airline.utils.UserFileHandler;
import java.sql.*;
import java.util.Scanner;

public class UserService implements UserOperations {

    Scanner sc = new Scanner(System.in);

    // 🔥 SESSION USER (IMPORTANT FIX)
    String currentUser;

    // ================= REGISTER =================
    public void register() {
        try {
            Connection con = DBSetup.getConnection();

            System.out.print("Username: ");
            String u = sc.next();

            System.out.print("Password: ");
            String p = sc.next();

            System.out.print("Email: ");
            String email = sc.next();

            System.out.print("Contact Number: ");
            String contact = sc.next();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO users VALUES(?,?,?,?)");

            ps.setString(1, u);
            ps.setString(2, p);
            ps.setString(3, email);
            ps.setString(4, contact);

            ps.executeUpdate();

            new UserFileHandler(
                    "Username: " + u +
                    " | Email: " + email +
                    " | Contact: " + contact
            ).start();

            System.out.println("✅ Registered Successfully!");

            // 🔥 AUTO LOGIN AFTER REGISTER
            currentUser = u;
            System.out.println("🔐 Auto Login Successful!");
            menu();

        } catch (Exception e) {
            System.out.println("❌ Registration Failed: " + e.getMessage());
        }
    }

    // ================= LOGIN =================
    public void login() {
        try {
            Connection con = DBSetup.getConnection();

            System.out.print("Username: ");
            String u = sc.next();

            System.out.print("Password: ");
            String p = sc.next();

            PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM users WHERE username=? AND password=?");

            ps.setString(1, u);
            ps.setString(2, p);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                currentUser = u;
                System.out.println("✅ Login Successful!");
                menu();
            } else {
                System.out.println("❌ Invalid Login!");
            }

        } catch (Exception e) {
            System.out.println("❌ Login Error: " + e.getMessage());
        }
    }

    // ================= MENU =================
    public void menu() {
        while (true) {
            System.out.println("\n========== USER MENU ==========");
            System.out.println("1. Search Flights");
            System.out.println("2. View Flights");
            System.out.println("3. Book Ticket");
            System.out.println("4. Cancel Ticket");
            System.out.println("5. View My Bookings");
            System.out.println("0. Logout");

            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    searchFlights();
                    break;
                case 2:
                    viewFlights();
                    break;
                case 3:
                    bookTicket();
                    break;
                case 4:
                    cancelTicket();
                    break;
                case 5:
                    viewBooking();
                    break;
                case 0:
                    currentUser = null; // Clear session
                    return;
                default:
                    System.out.println("❌ Invalid Choice!");
            }
        }
    }

    // ================= SEARCH FLIGHTS =================
   public void searchFlights() {
    try {
        Connection con = DBSetup.getConnection();

        System.out.print("Source: ");
        String s = sc.next();

        System.out.print("Destination: ");
        String d = sc.next();

        PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM flights WHERE source=? AND destination=? AND seats > 0"
        );

        ps.setString(1, s);
        ps.setString(2, d);

        ResultSet rs = ps.executeQuery();

        if (!rs.next()) {
            System.out.println("❌ No flights available for this route!");
            return;
        }

        System.out.println("\n✈️ ===== AVAILABLE FLIGHTS =====");

        do {
            System.out.println(
                    "Flight ID     : " + rs.getInt("flight_id") +
                    "\nSource        : " + rs.getString("source") +
                    "\nDestination   : " + rs.getString("destination") +
                    "\nTime          : " + rs.getString("time") +
                    "\nPrice         : ₹" + rs.getDouble("price") +
                    "\nSeats Left    : " + rs.getInt("seats") +
                    "\nTotal Seats   : " + rs.getInt("total_seats") +
                    "\nAirline       : " + rs.getString("airline") +
                    "\nDate          : " + rs.getString("flight_date") +
                    "\n-----------------------------------"
            );
        } while (rs.next());

    } catch (Exception e) {
        System.out.println("❌ Search Error: " + e.getMessage());
    }
}
    // ================= VIEW FLIGHTS =================
     public void viewFlights() {

    try {

        Connection con = DBSetup.getConnection();

        ResultSet rs = con.createStatement()
                .executeQuery("SELECT * FROM flights");

        System.out.println("\n✈️ ===== ALL FLIGHT DETAILS =====");

        while (rs.next()) {

            System.out.println(
                    "Flight ID   : " + rs.getInt(1) +
                    "\nSource       : " + rs.getString(2) +
                    "\nDestination  : " + rs.getString(3) +
                    "\nTime         : " + rs.getString(4) +
                    "\nPrice        : ₹" + rs.getDouble(5) +
                    "\nSeats Left   : " + rs.getInt(6) +
                    "\nTotal Seats  : " + rs.getInt(7) +
                    "\nAirline      : " + rs.getString(8) +
                    "\nDate         : " + rs.getString(9) +
                    "\n-----------------------------------"
            );
        }

    } catch (Exception e) {
        System.out.println("❌ View Error: " + e.getMessage());
    }
}

    // ================= AUTO-GENERATE BOOKING ID =================
    private int generateBookingId(Connection con) throws SQLException {
        ResultSet rs = con.createStatement()
                .executeQuery("SELECT COALESCE(MAX(booking_id), 0) + 1 as next_id FROM bookings");
        rs.next();
        return rs.getInt("next_id");
    }

    // ================= GET AVAILABLE SEATS FOR FLIGHT =================
    private ResultSet getAvailableSeats(Connection con, int flightId) throws SQLException {
        PreparedStatement ps = con.prepareStatement(
                "SELECT seats FROM flights WHERE flight_id=?");
        ps.setInt(1, flightId);
        return ps.executeQuery();
    }

    // ================= BOOK TICKET WITH SEAT SELECTION =================
    public void bookTicket() {
    try {
        Connection con = DBSetup.getConnection();

        // ================= NEW SEARCH FLOW =================
        System.out.print("Enter Source: ");
        String source = sc.next();

        System.out.print("Enter Destination: ");
        String destination = sc.next();

        System.out.print("Enter Date (YYYY-MM-DD): ");
        String date = sc.next();

        PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM flights WHERE source=? AND destination=? AND flight_date=? AND seats > 0"
        );

        ps.setString(1, source);
        ps.setString(2, destination);
        ps.setString(3, date);

        ResultSet rs = ps.executeQuery();

        System.out.println("\n✈ Available Flights:");
        boolean found = false;

        while (rs.next()) {
            found = true;
            System.out.println(
                    "Flight ID: " + rs.getInt("flight_id") +
                    " | Airline: " + rs.getString("airline") +
                    " | " + rs.getString("source") + " → " + rs.getString("destination") +
                    " | Time: " + rs.getString("time") +
                    " | Date: " + rs.getString("flight_date") +
                    " | Price: ₹" + rs.getDouble("price") +
                    " | Seats: " + rs.getInt("seats")
            );
        }

        if (!found) {
            System.out.println("❌ No flights found for this route!");
            return;
        }

        // ================= SELECT FLIGHT =================
        System.out.print("\nEnter Flight ID to Book: ");
        int fid = sc.nextInt();

        // CHECK SEATS
        PreparedStatement seatPs = con.prepareStatement(
                "SELECT seats, total_seats FROM flights WHERE flight_id=?"
        );
        seatPs.setInt(1, fid);

        ResultSet seatRs = seatPs.executeQuery();

        if (!seatRs.next() || seatRs.getInt("seats") <= 0) {
            System.out.println("❌ No seats available!");
            return;
        }

        int availableSeats = seatRs.getInt("seats");

        int passengerId = seatRs.getInt("total_seats") - availableSeats + 1;

       

        sc.nextLine(); // buffer clear

        // ================= PASSENGER DETAILS =================
        System.out.print("Passenger Name: ");
        String name = sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Contact: ");
        String contact = sc.nextLine();

        // ================= BOOKING INSERT =================
PreparedStatement bookingPs = con.prepareStatement(
        "INSERT INTO bookings (flight_id, passenger_name, username, seat_number) VALUES(?,?,?,?)",
        Statement.RETURN_GENERATED_KEYS
);

bookingPs.setInt(1, fid);
bookingPs.setString(2, name);
bookingPs.setString(3, currentUser);
bookingPs.setString(4, "A1");

bookingPs.executeUpdate();

// GET AUTO GENERATED BOOKING ID
ResultSet bookingKeys = bookingPs.getGeneratedKeys();
int bookingId = 0;

if (bookingKeys.next()) {
    bookingId = bookingKeys.getInt(1);
}

        // ================= PASSENGER INSERT =================
        PreparedStatement passengerPs = con.prepareStatement(
                "INSERT INTO passengers (passenger_id, flight_id, name, email, contact) VALUES(?,?,?,?,?)"
        );

        passengerPs.setInt(1, passengerId);
        passengerPs.setInt(2, fid);
        passengerPs.setString(3, name);
        passengerPs.setString(4, email);
        passengerPs.setString(5, contact);

        passengerPs.executeUpdate();

        // ================= UPDATE SEATS =================
        PreparedStatement update = con.prepareStatement(
                "UPDATE flights SET seats = seats - 1 WHERE flight_id=?"
        );

        update.setInt(1, fid);
        update.executeUpdate();

        // ================= LOG FILES =================
        new BookingFileHandler(
                "Flight ID: " + fid +
                " | User: " + currentUser +
                " | Passenger: " + name
        ).start();

        new PassengerFileHandler(
                "Passenger ID: " + passengerId +
                " | Name: " + name +
                " | Email: " + email
        ).start();

        System.out.println("🎉 Ticket Booked Successfully!");
System.out.println("📄 Booking Completed!");

System.out.println("\n📌 ===== BOOKING DETAILS =====");
System.out.println("Booking ID   : " + bookingId);
System.out.println("Passenger ID : " + passengerId);
System.out.println("Flight ID    : " + fid);
System.out.println("Passenger    : " + name);

    } catch (Exception e) {
        System.out.println("❌ Booking Error: " + e.getMessage());
    }
}

    // ================= CANCEL TICKET =================
    public void cancelTicket() {
    try {
        Connection con = DBSetup.getConnection();

        System.out.print("Booking ID: ");
        int bid = sc.nextInt();

        System.out.print("Enter Flight Date (YYYY-MM-DD): ");
        String date = sc.next();

        System.out.print("Enter Flight Time: ");
        String time = sc.next();

        PreparedStatement getData = con.prepareStatement(
                "SELECT b.flight_id, b.passenger_name, p.id " +
                "FROM bookings b " +
                "JOIN passengers p ON b.passenger_name = p.name " +
                "JOIN flights f ON b.flight_id = f.flight_id " +
                "WHERE b.booking_id=? AND b.username=? " +
                "AND f.flight_date=? AND f.time=?"
        );

        getData.setInt(1, bid);
        getData.setString(2, currentUser);
        getData.setString(3, date);
        getData.setString(4, time);

        ResultSet rs = getData.executeQuery();

        if (rs.next()) {
            int fid = rs.getInt(1);
            int pid = rs.getInt(3);

            PreparedStatement deleteBooking = con.prepareStatement(
                    "DELETE FROM bookings WHERE booking_id=?");
            deleteBooking.setInt(1, bid);
            deleteBooking.executeUpdate();

            PreparedStatement deletePassenger = con.prepareStatement(
                    "DELETE FROM passengers WHERE id=?");
            deletePassenger.setInt(1, pid);
            deletePassenger.executeUpdate();

            PreparedStatement updateSeats = con.prepareStatement(
                    "UPDATE flights SET seats = seats + 1 WHERE flight_id=?");
            updateSeats.setInt(1, fid);
            updateSeats.executeUpdate();

            BookingFileHandler.deleteBooking(bid);
            PassengerFileHandler.deletePassenger(pid);

            System.out.println("✅ Booking Cancelled Successfully!");
            System.out.println("✈️ Seat restored for Flight ID: " + fid);

        } else {
            System.out.println("❌ Booking Not Found or Date/Time mismatch!");
        }

    } catch (Exception e) {
        System.out.println("❌ Cancel Error: " + e.getMessage());
    }
}

    // ================= VIEW MY BOOKINGS WITH PASSENGER ID =================
    public void viewBooking() {
    try {
        Connection con = DBSetup.getConnection();

        String sql =
        "SELECT " +
        "b.booking_id, " +
        "b.seat_number, " +
        "b.booked_at, " +
        "p.passenger_id, " +
        "p.name, " +
        "p.email, " +
        "p.contact, " +
        "f.flight_id, " +
        "f.source, " +
        "f.destination, " +
        "f.flight_date, " +
        "f.time " +
        "FROM bookings b " +
        "JOIN passengers p ON b.passenger_name = p.name " +
        "JOIN flights f ON b.flight_id = f.flight_id " +
        "WHERE b.username = ? " +
        "ORDER BY b.booking_id DESC";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, currentUser);

        ResultSet rs = ps.executeQuery();

        System.out.println("\n📌 ===== MY BOOKINGS (FULL TICKET VIEW) =====");

        System.out.println("BookingID | FlightID | From → To | Date | Time | Seat | Name | Email | Contact");

        System.out.println("--------------------------------------------------------------------------------");

        boolean hasBookings = false;

        while (rs.next()) {

            hasBookings = true;

            System.out.println(
                    rs.getInt("booking_id") + " | " +
                    rs.getInt("flight_id") + " | " +
                    rs.getString("source") + " → " + rs.getString("destination") + " | " +
                    rs.getString("flight_date") + " | " +
                    rs.getString("time") + " | " +
                    rs.getString("seat_number") + " | " +
                    rs.getString("name") + " | " +
                    rs.getString("email") + " | " +
                    rs.getString("contact")
            );
        }

        if (!hasBookings) {
            System.out.println("❌ No bookings found!");
        }

    } catch (Exception e) {
        System.out.println("❌ View Bookings Error: " + e.getMessage());
    }
}
}