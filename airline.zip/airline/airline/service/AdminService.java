package airline.service;

import airline.db.DBSetup;
import airline.utils.BookingFileHandler;
import airline.utils.FlightFileHandler;
import java.sql.*;
import java.util.Scanner;

public class AdminService implements AdminOperations {

    Scanner sc = new Scanner(System.in);

    String ADMIN_USER = "admin";
    String ADMIN_PASS = "1234";

    // ================= LOGIN =================
    public boolean login() {

        System.out.print("Username: ");
        String u = sc.next();

        System.out.print("Password: ");
        String p = sc.next();

        return u.equals(ADMIN_USER) && p.equals(ADMIN_PASS);
    }

    // ================= MENU =================
    public void menu() {

        while (true) {

            System.out.println("\n========== ADMIN MENU ==========");
            System.out.println("1.Add Flight");
            System.out.println("2.Update Flight");
            System.out.println("3.Delete Flight");
            System.out.println("4.View Flights");
            System.out.println("5.View Passengers");
            System.out.println("6.Search Passenger");
            System.out.println("7.View Bookings");
            System.out.println("8.Cancel Booking");
            System.out.println("9.Reports");
            System.out.println("0.Exit");

            int ch = sc.nextInt();

            switch (ch) {

                case 1 -> addFlight();
                case 2 -> updateFlight();
                case 3 -> deleteFlight();
                case 4 -> viewFlights();
                case 5 -> viewPassengerBookings();
                case 6 -> searchPassenger();
                case 7 -> viewBookings();
                case 8 -> cancelBooking();
                case 9 -> reports();
                case 0 -> {
                    return;
                }
                default -> System.out.println("Invalid Choice!");
            }
        }
    }

    // ================= ADD FLIGHT (FIXED) =================
    public void addFlight() {

        try {

            Connection con = DBSetup.getConnection();

            System.out.print("Flight ID: ");
            int id = sc.nextInt();

            System.out.print("Source: ");
            String source = sc.next();

            System.out.print("Destination: ");
            String destination = sc.next();

            System.out.print("Time: ");
            String time = sc.next();

            System.out.print("Price: ");
            double price = sc.nextDouble();

            System.out.print("Seats: ");
            int seats = sc.nextInt();

            System.out.print("Total Seats: ");
            int totalSeats = sc.nextInt();

            // ✈ NEW FIELDS
            System.out.print("Airline Name: ");
            String airline = sc.next();

            System.out.print("Flight Date (YYYY-MM-DD): ");
            String flightDate = sc.next();

            PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO flights VALUES(?,?,?,?,?,?,?,?,?)"
            );

            ps.setInt(1, id);
            ps.setString(2, source);
            ps.setString(3, destination);
            ps.setString(4, time);
            ps.setDouble(5, price);
            ps.setInt(6, seats);
            ps.setInt(7, totalSeats);
            ps.setString(8, airline);
            ps.setString(9, flightDate);

            ps.executeUpdate();

            new FlightFileHandler(
                    "Flight ID: " + id +
                    " | Airline: " + airline +
                    " | Date: " + flightDate +
                    " | " + source + " → " + destination +
                    " | Price: " + price +
                    " | Seats: " + seats
            ).start();

            System.out.println("✅ Flight Added Successfully!");

        } catch (Exception e) {
            System.out.println("❌ Add Flight Error: " + e.getMessage());
        }
    }


    // ================= UPDATE FLIGHT =================
    public void updateFlight() {

        try {

            Connection con = DBSetup.getConnection();

            System.out.print("Flight ID: ");
            int id = sc.nextInt();

            System.out.print("New Price: ");
            double price = sc.nextDouble();

            PreparedStatement ps = con.prepareStatement(
                    "UPDATE flights SET price=? WHERE flight_id=?"
            );

            ps.setDouble(1, price);
            ps.setInt(2, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {

                FlightFileHandler.deleteFlight(id);
                System.out.println("✏ Flight Updated!");
            } else {
                System.out.println("❌ Flight Not Found!");
            }

        } catch (Exception e) {
            System.out.println("❌ Update Error: " + e.getMessage());
        }
    }

    // ================= DELETE FLIGHT =================
    public void deleteFlight() {

        try {

            Connection con = DBSetup.getConnection();

            System.out.print("Flight ID: ");
            int id = sc.nextInt();

            PreparedStatement ps = con.prepareStatement(
                    "DELETE FROM flights WHERE flight_id=?"
            );

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                FlightFileHandler.deleteFlight(id);
                System.out.println("🗑 Flight Deleted!");
            } else {
                System.out.println("❌ Flight Not Found!");
            }

        } catch (Exception e) {
            System.out.println("❌ Delete Error: " + e.getMessage());
        }
    }

    // ================= VIEW FLIGHTS =================
    public void viewFlights() {

    try {

        Connection con = DBSetup.getConnection();

        ResultSet rs = con.createStatement()
                .executeQuery("SELECT * FROM flights");

        System.out.println("\n✈️ ===== ALL FLIGHT DETAILS =====");

        while (rs.next()) {

            System.out.println(
                    "Flight ID   : " + rs.getInt(1) +
                    "\nSource       : " + rs.getString(2) +
                    "\nDestination  : " + rs.getString(3) +
                    "\nTime         : " + rs.getString(4) +
                    "\nPrice        : ₹" + rs.getDouble(5) +
                    "\nSeats Left   : " + rs.getInt(6) +
                    "\nTotal Seats  : " + rs.getInt(7) +
                    "\nAirline      : " + rs.getString(8) +
                    "\nDate         : " + rs.getString(9) +
                    "\n-----------------------------------"
            );
        }

    } catch (Exception e) {
        System.out.println("❌ View Error: " + e.getMessage());
    }
}

    // ================= VIEW PASSENGERS =================
    public void viewPassengerBookings() {

    try {

        Connection con = DBSetup.getConnection();

        String sql =
                "SELECT " +
                "b.booking_id, " +
                "b.seat_number, " +
                "b.booked_at, " +
                "p.passenger_id, " +
                "p.name, " +
                "p.email, " +
                "p.contact, " +
                "f.flight_id, " +
                "f.source, " +
                "f.destination, " +
                "f.flight_date, " +
                "f.time " +
                "FROM bookings b " +
                "JOIN passengers p ON b.passenger_name = p.name " +
                "JOIN flights f ON b.flight_id = f.flight_id";

        ResultSet rs = con.createStatement().executeQuery(sql);

        System.out.println("\n📋 ===== FULL BOOKING REPORT =====");

        while (rs.next()) {

            System.out.println(
                    "Booking ID   : " + rs.getInt("booking_id") +
                    "\nPassenger ID : " + rs.getInt("passenger_id") +
                    "\nName         : " + rs.getString("name") +
                    "\nEmail        : " + rs.getString("email") +
                    "\nContact      : " + rs.getString("contact") +
                    "\nFlight ID    : " + rs.getInt("flight_id") +
                    "\nSource       : " + rs.getString("source") +
                    "\nDestination  : " + rs.getString("destination") +
                    "\nDate         : " + rs.getString("flight_date") +
                    "\nTime         : " + rs.getString("time") +
                    "\nSeat Number  : " + rs.getString("seat_number") +
                    "\nBooked At    : " + rs.getTimestamp("booked_at") +
                    "\n-----------------------------------"
            );
        }

    } catch (Exception e) {
        System.out.println("❌ Error: " + e.getMessage());
    }
}

    // ================= SEARCH PASSENGER =================
    public void searchPassenger() {

    try {

        Connection con = DBSetup.getConnection();

        System.out.print("Passenger Name: ");
        String name = sc.next();

        String sql =
                "SELECT " +
                "b.booking_id, " +
                "b.seat_number, " +
                "b.booked_at, " +
                "p.passenger_id, " +
                "p.name, " +
                "p.email, " +
                "p.contact, " +
                "f.flight_id, " +
                "f.source, " +
                "f.destination, " +
                "f.flight_date, " +
                "f.time " +
                "FROM passengers p " +
                "JOIN bookings b ON p.name = b.passenger_name " +
                "JOIN flights f ON b.flight_id = f.flight_id " +
                "WHERE p.name = ?";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, name);

        ResultSet rs = ps.executeQuery();

        boolean found = false;

        System.out.println("\n🔍 ===== PASSENGER FULL DETAILS =====");

        while (rs.next()) {

            found = true;

            System.out.println(
                    "Booking ID   : " + rs.getInt("booking_id") +
                    "\nPassenger ID : " + rs.getInt("passenger_id") +
                    "\nName         : " + rs.getString("name") +
                    "\nEmail        : " + rs.getString("email") +
                    "\nContact      : " + rs.getString("contact") +
                    "\nFlight ID    : " + rs.getInt("flight_id") +
                    "\nSource       : " + rs.getString("source") +
                    "\nDestination  : " + rs.getString("destination") +
                    "\nDate         : " + rs.getString("flight_date") +
                    "\nTime         : " + rs.getString("time") +
                    "\nSeat Number  : " + rs.getString("seat_number") +
                    "\nBooked At    : " + rs.getTimestamp("booked_at") +
                    "\n-----------------------------------"
            );
        }

        if (!found) {
            System.out.println("❌ No passenger booking found!");
        }

    } catch (Exception e) {
        System.out.println("❌ Search Error: " + e.getMessage());
    }
}

    // ================= BOOKINGS =================
    public void viewBookings() {

    try {

        Connection con = DBSetup.getConnection();

        String sql =
                "SELECT " +
                "b.booking_id, " +
                "b.seat_number, " +
                "b.booked_at, " +
                "p.passenger_id, " +
                "p.name, " +
                "p.email, " +
                "p.contact, " +
                "f.flight_id, " +
                "f.source, " +
                "f.destination, " +
                "f.flight_date, " +
                "f.time " +
                "FROM bookings b " +
                "JOIN passengers p ON b.passenger_name = p.name " +
                "JOIN flights f ON b.flight_id = f.flight_id";

        ResultSet rs = con.createStatement().executeQuery(sql);

        System.out.println("\n📋 ===== ALL BOOKINGS FULL REPORT =====");

        boolean found = false;

        while (rs.next()) {

            found = true;

            System.out.println(
                    "Booking ID   : " + rs.getInt("booking_id") +
                    "\nPassenger ID : " + rs.getInt("passenger_id") +
                    "\nName         : " + rs.getString("name") +
                    "\nEmail        : " + rs.getString("email") +
                    "\nContact      : " + rs.getString("contact") +
                    "\nFlight ID    : " + rs.getInt("flight_id") +
                    "\nSource       : " + rs.getString("source") +
                    "\nDestination  : " + rs.getString("destination") +
                    "\nDate         : " + rs.getString("flight_date") +
                    "\nTime         : " + rs.getString("time") +
                    "\nSeat Number  : " + rs.getString("seat_number") +
                    "\nBooked At    : " + rs.getTimestamp("booked_at") +
                    "\n-----------------------------------"
            );
        }

        if (!found) {
            System.out.println("❌ No bookings found!");
        }

    } catch (Exception e) {
        System.out.println("❌ Booking Error: " + e.getMessage());
    }
}

    // ================= CANCEL BOOKING =================
    public void cancelBooking() {

        try {

            Connection con = DBSetup.getConnection();

            System.out.print("Booking ID: ");
            int bid = sc.nextInt();

            PreparedStatement ps = con.prepareStatement(
                    "SELECT flight_id FROM bookings WHERE booking_id=?"
            );

            ps.setInt(1, bid);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                int fid = rs.getInt(1);

                con.prepareStatement(
                        "DELETE FROM bookings WHERE booking_id=" + bid
                ).executeUpdate();

                con.prepareStatement(
                        "UPDATE flights SET seats = seats + 1 WHERE flight_id=" + fid
                ).executeUpdate();

                BookingFileHandler.deleteBooking(bid);

                System.out.println("✅ Booking Cancelled!");

            } else {
                System.out.println("❌ Not Found!");
            }

        } catch (Exception e) {
            System.out.println("❌ Cancel Error: " + e.getMessage());
        }
    }

    // ================= REPORT =================
    public void reports() {

        try {

            Connection con = DBSetup.getConnection();

            ResultSet rs = con.createStatement()
                    .executeQuery("SELECT COUNT(*) FROM bookings");

            if (rs.next()) {
                System.out.println("📊 Total Bookings: " + rs.getInt(1));
            }

        } catch (Exception e) {
            System.out.println("❌ Report Error: " + e.getMessage());
        }
    }
}