import airline.db.DBSetup;
import airline.service.AdminService;
import airline.service.UserService;
import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {

        DBSetup.init(); // AUTO DB CREATE

        Scanner sc = new Scanner(System.in);

        UserService user = new UserService();
        AdminService admin = new AdminService();

        while (true) {

            System.out.println("\nWHO ARE YOU?");
            System.out.println("1.Admin 2.User 0.Exit");

            int ch = sc.nextInt();

            switch (ch) {

                case 1:
                    if (admin.login()) {
                        admin.menu();
                    } else {
                        System.out.println("Wrong Login!");
                    }
                    break;

                case 2:
                    while (true) {

                        System.out.println("\nUSER OPTIONS");
                        System.out.println("1.Register");
                        System.out.println("2.Login");
                        System.out.println("0.Back");

                        int op = sc.nextInt();

                        if (op == 1) {
                            user.register();
                        }
                        else if (op == 2) {
                            user.login();   // after login -> menu inside UserService
                            break;
                        }
                        else if (op == 0) {
                            break;
                        }
                        else {
                            System.out.println("Invalid option!");
                        }
                    }
                    break;

                case 0:
                    System.exit(0);
            }
        }
    }
}