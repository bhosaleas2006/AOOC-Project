package airline.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBSetup {

    private static Connection con;

    public static void init() {
        try {

            Connection tempCon = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/",
                    "root",
                    "TEJAS@98"
            );

            Statement st = tempCon.createStatement();

            st.executeUpdate("CREATE DATABASE IF NOT EXISTS airline_db");

            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/airline_db",
                    "root",
                    "TEJAS@98"
            );

            Statement stmt = con.createStatement();

            // ✈ FLIGHTS (UPDATED)
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS flights (" +
                "flight_id INT PRIMARY KEY," +
                "source VARCHAR(50)," +
                "destination VARCHAR(50)," +
                "time VARCHAR(50)," +
                "price DOUBLE," +
                "seats INT," +
                "total_seats INT," +
                "airline VARCHAR(50)," +
                "flight_date VARCHAR(20)" +
                ")"
            );

            // USERS
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS users (" +
                "username VARCHAR(50) PRIMARY KEY," +
                "password VARCHAR(50)," +
                "email VARCHAR(100)," +
                "contact VARCHAR(15)" +
                ")"
            );

            // BOOKINGS
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS bookings (" +
                "booking_id INT AUTO_INCREMENT PRIMARY KEY," +
                "flight_id INT," +
                "passenger_name VARCHAR(50)," +
                "username VARCHAR(50)," +
                "seat_number VARCHAR(10)," +
                "booked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
                ")"
            );

            // PASSENGERS
            stmt.executeUpdate(
                "CREATE TABLE IF NOT EXISTS passengers (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "passenger_id INT," +
                "flight_id INT," +
                "name VARCHAR(50)," +
                "email VARCHAR(100)," +
                "contact VARCHAR(15)," +
                "UNIQUE KEY uq_flight_passenger (flight_id, passenger_id)" +
                ")"
            );

            System.out.println("Database & Tables Ready!");

        } catch (Exception e) {
            System.out.println("DB Error: " + e.getMessage());
        }
    }

    public static Connection getConnection() {
        return con;
    }
}