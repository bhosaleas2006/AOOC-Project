package airline.model;

public class Flight {
    public int flightId;
    public String source, destination, time;
    public double price;
    public int seats;

    public Flight(int flightId, String source, String destination,
                  String time, double price, int seats) {
        this.flightId = flightId;
        this.source = source;
        this.destination = destination;
        this.time = time;
        this.price = price;
        this.seats = seats;
    }
}
