package airline.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class LoginFrame extends JFrame {

    public LoginFrame() {
        setTitle("SkyLine Airline Reservation System");
        setSize(520, 440);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        // Root: white background
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);

        // Top line (simple border instead of colored strip)
        JPanel strip = new JPanel();
        strip.setBackground(Color.LIGHT_GRAY);
        strip.setPreferredSize(new Dimension(0, 2));
        root.add(strip, BorderLayout.NORTH);

        // Centre content
        JPanel centre = new JPanel();
        centre.setBackground(Color.WHITE);
        centre.setLayout(new BoxLayout(centre, BoxLayout.Y_AXIS));
        centre.setBorder(new EmptyBorder(48, 60, 32, 60));

        // Icon (plain text, no circle background)
        JLabel icon = new JLabel("✈️");
        icon.setFont(new Font("Dialog", Font.PLAIN, 48));
        icon.setForeground(Color.BLACK);
        icon.setHorizontalAlignment(SwingConstants.CENTER);
        icon.setAlignmentX(CENTER_ALIGNMENT);

        JLabel title = new JLabel("SkyLine Reservations");
        title.setFont(new Font("Dialog", Font.BOLD, 22));
        title.setForeground(Color.BLACK);
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel sub = new JLabel("Select your role to continue");
        sub.setFont(new Font("Dialog", Font.PLAIN, 13));
        sub.setForeground(Color.DARK_GRAY);
        sub.setAlignmentX(CENTER_ALIGNMENT);

        // Divider
        JSeparator div = new JSeparator();
        div.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        div.setForeground(Color.GRAY);

        // Button row
        JPanel btnRow = new JPanel(new GridLayout(1, 2, 16, 0));
        btnRow.setBackground(Color.WHITE);
        btnRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));

        JButton adminBtn = new JButton("Admin Login");
        JButton userBtn = new JButton("User Portal");
        
        // Style buttons simply
        adminBtn.setFont(new Font("Dialog", Font.BOLD, 13));
        userBtn.setFont(new Font("Dialog", Font.BOLD, 13));
        adminBtn.setBackground(Color.LIGHT_GRAY);
        userBtn.setBackground(Color.LIGHT_GRAY);
        adminBtn.setForeground(Color.BLACK);
        userBtn.setForeground(Color.BLACK);
        adminBtn.setFocusPainted(true);
        userBtn.setFocusPainted(true);
        adminBtn.setPreferredSize(new Dimension(0, 52));
        userBtn.setPreferredSize(new Dimension(0, 52));

        adminBtn.addActionListener(e -> new AdminLoginDialog(this).setVisible(true));
        userBtn.addActionListener(e -> { 
            new UserPortalFrame().setVisible(true); 
            dispose(); 
        });

        btnRow.add(adminBtn);
        btnRow.add(userBtn);

        centre.add(icon);
        centre.add(Box.createVerticalStrut(16));
        centre.add(title);
        centre.add(Box.createVerticalStrut(6));
        centre.add(sub);
        centre.add(Box.createVerticalStrut(28));
        centre.add(div);
        centre.add(Box.createVerticalStrut(28));
        centre.add(btnRow);

        // Footer
        JLabel footer = new JLabel("©SkyLine Airlines");
        footer.setFont(new Font("Dialog", Font.PLAIN, 10));
        footer.setForeground(Color.GRAY);
        footer.setHorizontalAlignment(SwingConstants.CENTER);
        footer.setBorder(new EmptyBorder(0, 0, 14, 0));

        root.add(centre, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);
    }
}