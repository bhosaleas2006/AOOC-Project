package airline.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

public class UIUtils {

    // ── Minimal colors (only black, white, and one gray) ────
    public static final Color BG_PAGE     = Color.WHITE;
    public static final Color BG_DARK     = Color.WHITE;
    public static final Color BG_WHITE    = Color.WHITE;
    public static final Color BG_CARD     = Color.WHITE;
    public static final Color BG_FIELD    = Color.WHITE;
    public static final Color BG_HEADER   = Color.LIGHT_GRAY;

    public static final Color BORDER_COLOR = Color.BLACK;
    public static final Color DIVIDER      = Color.BLACK;

    public static final Color ACCENT_BLUE  = Color.BLACK;
    public static final Color ACCENT_GREEN = Color.BLACK;
    public static final Color ACCENT_RED   = Color.BLACK;
    public static final Color ACCENT_AMBER = Color.BLACK;
    public static final Color ACCENT_INDIGO= Color.BLACK;

    public static final Color TEXT_PRIMARY = Color.BLACK;
    public static final Color TEXT_MUTED   = Color.BLACK;
    public static final Color TEXT_DIM     = Color.BLACK;
    public static final Color TEXT_WHITE   = Color.BLACK;

    // ── Plain system fonts ──────────────────────────────────
    public static final Font FONT_TITLE   = new Font("Dialog", Font.BOLD, 22);
    public static final Font FONT_HEADING = new Font("Dialog", Font.BOLD, 15);
    public static final Font FONT_BOLD    = new Font("Dialog", Font.BOLD, 13);
    public static final Font FONT_BODY    = new Font("Dialog", Font.PLAIN, 13);
    public static final Font FONT_SMALL   = new Font("Dialog", Font.PLAIN, 11);

    // ── Label ────────────────────────────────────────────────
    public static JLabel label(String text, Font font, Color fg) {
        JLabel l = new JLabel(text);
        l.setFont(font);
        l.setForeground(Color.BLACK);
        return l;
    }

    // ── Text Field ───────────────────────────────────────────
    public static JTextField textField() {
        JTextField tf = new JTextField();
        styleInput(tf);
        return tf;
    }

    public static JPasswordField passwordField() {
        JPasswordField pf = new JPasswordField();
        styleInput(pf);
        return pf;
    }

    private static void styleInput(JTextField tf) {
        tf.setFont(FONT_BODY);
        tf.setBackground(Color.WHITE);
        tf.setForeground(Color.BLACK);
        tf.setCaretColor(Color.BLACK);
        tf.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        tf.setPreferredSize(new Dimension(160, 30));
    }

    // ── Button (plain standard button) ───────────────────────
    public static JButton button(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BOLD);
        btn.setForeground(Color.BLACK);
        btn.setBackground(Color.LIGHT_GRAY);
        return btn;
    }

    // ── Card panel ───────────────────────────────────────────
    public static JPanel createCardPanel() {
        JPanel p = new JPanel();
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        return p;
    }

    // ── Table (minimal styling) ──────────────────────────────
    public static void styleTable(JTable table) {
        table.setFont(FONT_BODY);
        table.setForeground(Color.BLACK);
        table.setBackground(Color.WHITE);
        table.setGridColor(Color.BLACK);
        table.setRowHeight(30);
        table.setSelectionBackground(Color.LIGHT_GRAY);
        table.setSelectionForeground(Color.BLACK);

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_BOLD);
        header.setBackground(Color.LIGHT_GRAY);
        header.setForeground(Color.BLACK);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK));
    }

    // ── Scroll pane ──────────────────────────────────────────
    public static JScrollPane scrollPane(JTable table) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBackground(Color.WHITE);
        sp.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        return sp;
    }

    // ── Dialogs ──────────────────────────────────────────────
    public static void success(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void error(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
}