package airline.gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class AdminLoginDialog extends JDialog {

    private JTextField    userField;
    private JPasswordField passField;
    private final JFrame  parent;

    public AdminLoginDialog(JFrame parent) {
        super(parent, "Admin Login", true);
        this.parent = parent;
        setSize(400, 340);
        setLocationRelativeTo(parent);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);

        JPanel banner = new JPanel(new BorderLayout());
        banner.setBackground(UIUtils.ACCENT_BLUE);
        banner.setBorder(new EmptyBorder(18, 24, 18, 24));
        JLabel hdr = UIUtils.label("🔐  Admin Login", UIUtils.FONT_HEADING, Color.WHITE);
        JLabel sub = UIUtils.label("Enter your credentials", UIUtils.FONT_SMALL,
                new Color(0xBFD3FF));
        JPanel hdrText = new JPanel(new GridLayout(2, 1, 0, 2));
        hdrText.setOpaque(false);
        hdrText.add(hdr); hdrText.add(sub);
        banner.add(hdrText, BorderLayout.CENTER);

        // ── Form ──
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(24, 28, 8, 28));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill    = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        gbc.gridx   = 0;

        userField = UIUtils.textField();
        passField = UIUtils.passwordField();

        gbc.gridy = 0; gbc.insets = new Insets(0, 0, 3, 0);
        form.add(UIUtils.label("Username", UIUtils.FONT_SMALL, UIUtils.TEXT_MUTED), gbc);
        gbc.gridy = 1; gbc.insets = new Insets(0, 0, 14, 0);
        form.add(userField, gbc);
        gbc.gridy = 2; gbc.insets = new Insets(0, 0, 3, 0);
        form.add(UIUtils.label("Password", UIUtils.FONT_SMALL, UIUtils.TEXT_MUTED), gbc);
        gbc.gridy = 3; gbc.insets = new Insets(0, 0, 0, 0);
        form.add(passField, gbc);

        // ── Buttons ──
        JPanel btnRow = new JPanel(new GridLayout(1, 2, 12, 0));
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new EmptyBorder(20, 28, 24, 28));

        JButton loginBtn  = UIUtils.button("Login",  UIUtils.ACCENT_BLUE);
        JButton cancelBtn = UIUtils.button("Cancel", UIUtils.BG_FIELD);
        loginBtn.addActionListener(e  -> doLogin());
        cancelBtn.addActionListener(e -> dispose());
        btnRow.add(loginBtn); btnRow.add(cancelBtn);

        root.add(banner, BorderLayout.NORTH);
        root.add(form,   BorderLayout.CENTER);
        root.add(btnRow, BorderLayout.SOUTH);
        setContentPane(root);
        getRootPane().setDefaultButton(loginBtn);
    }

    private void doLogin() {
        String u = userField.getText().trim();
        String p = new String(passField.getPassword()).trim();
        if (u.equals("admin") && p.equals("1234")) {
            dispose(); parent.dispose();
            new AdminDashboard().setVisible(true);
        } else {
            UIUtils.error(this, "Invalid username or password!");
            passField.setText("");
        }
    }
}
