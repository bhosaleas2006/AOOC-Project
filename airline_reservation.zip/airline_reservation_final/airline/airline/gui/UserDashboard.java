package airline.gui;

import airline.db.DBSetup;
import airline.utils.BookingFileHandler;
import airline.utils.PassengerFileHandler;
import airline.utils.ValidationUtils;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;

public class UserDashboard extends JFrame {

    private final String currentUser;

    public UserDashboard(String username) {
        this.currentUser = username;
        setTitle("SkyLine — Welcome, " + username);
        setSize(1100, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Color.LIGHT_GRAY);
        bar.setBorder(new EmptyBorder(10, 20, 10, 20));
        
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        left.add(new JLabel("✈"));
        left.add(new JLabel("Welcome, " + currentUser));
        
        JButton logout = new JButton("Logout");
        logout.addActionListener(e -> { 
            dispose(); 
            new LoginFrame().setVisible(true); 
        });
        bar.add(left, BorderLayout.WEST);
        bar.add(logout, BorderLayout.EAST);

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Dialog", Font.PLAIN, 12));
        tabs.addTab("Search Flights", searchFlightsTab());
        tabs.addTab("All Flights", allFlightsTab());
        tabs.addTab("Book Ticket", bookTicketTab());
        tabs.addTab("Cancel Ticket", cancelTab());
        tabs.addTab("My Bookings", myBookingsTab());

        root.add(bar, BorderLayout.NORTH);
        root.add(tabs, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel pagePanel() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(15, 15, 15, 15));
        return p;
    }

    private static final String[] FLIGHT_COLS = {
        "Flight ID", "Airline", "Source", "Destination", "Date", "Time", "Price (₹)", "Avail. Seats", "Total Seats"
    };

    private void loadFlightRow(DefaultTableModel model, ResultSet rs) throws SQLException {
        model.addRow(new Object[]{
            rs.getInt("flight_id"),
            rs.getString("airline"),
            rs.getString("source"),
            rs.getString("destination"),
            rs.getString("flight_date"),
            rs.getString("time"),
            "₹" + rs.getDouble("price"),
            rs.getInt("seats"),
            rs.getInt("total_seats")
        });
    }

    private JPanel searchFlightsTab() {
        JPanel panel = pagePanel();

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        bar.setBackground(Color.WHITE);
        bar.setBorder(new EmptyBorder(0, 0, 10, 0));

        bar.add(new JLabel("From:"));
        JTextField srcF = new JTextField(12);
        bar.add(srcF);

        bar.add(new JLabel("To:"));
        JTextField dstF = new JTextField(12);
        bar.add(dstF);

        bar.add(new JLabel("Date (YYYY-MM-DD):"));
        JTextField dateF = new JTextField(12);
        bar.add(dateF);

        JButton search = new JButton("Search");
        JButton clear = new JButton("Clear");
        bar.add(search);
        bar.add(clear);

        DefaultTableModel model = new DefaultTableModel(FLIGHT_COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setFont(new Font("Dialog", Font.PLAIN, 11));
        table.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 11));

        search.addActionListener(e -> {
            String s = srcF.getText().trim();
            String d = dstF.getText().trim();
            String date = dateF.getText().trim();
            if (s.isEmpty() || d.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter From and To cities!");
                return;
            }
            model.setRowCount(0);
            try {
                String sql;
                PreparedStatement ps;
                if (date.isEmpty()) {
                    sql = "SELECT * FROM flights WHERE source=? AND destination=?";
                    ps = DBSetup.getConnection().prepareStatement(sql);
                    ps.setString(1, s);
                    ps.setString(2, d);
                } else {
                    sql = "SELECT * FROM flights WHERE source=? AND destination=? AND flight_date=?";
                    ps = DBSetup.getConnection().prepareStatement(sql);
                    ps.setString(1, s);
                    ps.setString(2, d);
                    ps.setString(3, date);
                }
                ResultSet rs = ps.executeQuery();
                while (rs.next()) loadFlightRow(model, rs);
                if (model.getRowCount() == 0)
                    JOptionPane.showMessageDialog(this, "No flights found for " + s + " → " + d +
                            (date.isEmpty() ? "" : " on " + date));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        clear.addActionListener(e -> {
            srcF.setText("");
            dstF.setText("");
            dateF.setText("");
            model.setRowCount(0);
        });

        panel.add(bar, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel allFlightsTab() {
        JPanel panel = pagePanel();

        DefaultTableModel model = new DefaultTableModel(FLIGHT_COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setFont(new Font("Dialog", Font.PLAIN, 11));
        table.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 11));

        JButton refresh = new JButton("Refresh");
        Runnable load = () -> {
            model.setRowCount(0);
            try {
                ResultSet rs = DBSetup.getConnection().createStatement()
                        .executeQuery(
                            "SELECT flight_id, airline, source, destination, flight_date, " +
                            "time, price, seats, total_seats FROM flights ORDER BY flight_date, time"
                        );
                while (rs.next()) loadFlightRow(model, rs);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        };
        refresh.addActionListener(e -> load.run());
        load.run();

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new EmptyBorder(0, 0, 10, 0));
        btnRow.add(refresh);

        panel.add(btnRow, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel bookTicketTab() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JPanel step1Card = new JPanel(new BorderLayout(0, 10));
        step1Card.setBackground(Color.WHITE);
        step1Card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                new EmptyBorder(15, 15, 15, 15)));

        JLabel step1Title = new JLabel("Step 1 — Find Available Flights");
        step1Title.setFont(new Font("Dialog", Font.BOLD, 12));
        step1Card.add(step1Title, BorderLayout.NORTH);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        searchBar.setBackground(Color.WHITE);
        searchBar.add(new JLabel("From:"));
        JTextField bookSrcF = new JTextField(10);
        searchBar.add(bookSrcF);
        searchBar.add(new JLabel("To:"));
        JTextField bookDstF = new JTextField(10);
        searchBar.add(bookDstF);
        searchBar.add(new JLabel("Date (YYYY-MM-DD):"));
        JTextField bookDateF = new JTextField(12);
        searchBar.add(bookDateF);
        JButton findFlightsBtn = new JButton("Find Flights");
        searchBar.add(findFlightsBtn);
        step1Card.add(searchBar, BorderLayout.CENTER);

        DefaultTableModel flightModel = new DefaultTableModel(FLIGHT_COLS, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable flightTable = new JTable(flightModel);
        flightTable.setFont(new Font("Dialog", Font.PLAIN, 11));
        flightTable.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 11));
        JScrollPane flightScroll = new JScrollPane(flightTable);
        flightScroll.setPreferredSize(new Dimension(0, 140));
        step1Card.add(flightScroll, BorderLayout.SOUTH);

        JPanel step2Card = new JPanel(new GridBagLayout());
        step2Card.setBackground(Color.WHITE);
        step2Card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                new EmptyBorder(15, 15, 15, 15)));

        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(5, 5, 5, 5);

        gc.gridx = 0;
        gc.gridy = 0;
        gc.gridwidth = 2;
        gc.weightx = 1;
        step2Card.add(new JLabel("Step 2 — Enter Booking Details"), gc);
        gc.gridwidth = 1;

        gc.gridx = 0;
        gc.gridy = 1;
        gc.weightx = 0;
        step2Card.add(new JLabel("Booking ID"), gc);
        JLabel bidLabel = new JLabel("(auto-assigned on booking)");
        bidLabel.setFont(new Font("Dialog", Font.PLAIN, 10));
        gc.gridx = 1;
        gc.weightx = 1;
        step2Card.add(bidLabel, gc);

        gc.gridx = 0;
        gc.gridy = 2;
        gc.weightx = 0;
        step2Card.add(new JLabel("Passenger ID"), gc);
        JLabel pidLabel = new JLabel("(auto — scoped to flight)");
        pidLabel.setFont(new Font("Dialog", Font.PLAIN, 10));
        gc.gridx = 1;
        gc.weightx = 1;
        step2Card.add(pidLabel, gc);

        gc.gridx = 0;
        gc.gridy = 3;
        gc.weightx = 0;
        step2Card.add(new JLabel("Flight ID"), gc);
        JPanel fidRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        fidRow.setBackground(Color.WHITE);
        JTextField fidF = new JTextField(8);
        JButton loadSeatsBtn = new JButton("Load Seats");
        fidRow.add(fidF);
        fidRow.add(loadSeatsBtn);
        gc.gridx = 1;
        gc.weightx = 1;
        step2Card.add(fidRow, gc);

        gc.gridx = 0;
        gc.gridy = 4;
        gc.weightx = 0;
        step2Card.add(new JLabel("Select Seat"), gc);
        JComboBox<String> seatCombo = new JComboBox<>();
        seatCombo.setEnabled(false);
        gc.gridx = 1;
        gc.weightx = 1;
        step2Card.add(seatCombo, gc);

        JTextField nameF = new JTextField(15);
        JTextField emailF = new JTextField(15);
        JTextField ctF = new JTextField(15);

        JLabel emailErrorLabel = new JLabel(" ");
        emailErrorLabel.setFont(new Font("Dialog", Font.PLAIN, 10));
        JLabel phoneErrorLabel = new JLabel(" ");
        phoneErrorLabel.setFont(new Font("Dialog", Font.PLAIN, 10));

        gc.gridx = 0;
        gc.gridy = 5;
        gc.weightx = 0;
        step2Card.add(new JLabel("Passenger Name"), gc);
        gc.gridx = 1;
        gc.weightx = 1;
        step2Card.add(nameF, gc);

        gc.gridx = 0;
        gc.gridy = 6;
        gc.weightx = 0;
        step2Card.add(new JLabel("Email"), gc);
        gc.gridx = 1;
        gc.weightx = 1;
        step2Card.add(emailF, gc);

        gc.gridx = 1;
        gc.gridy = 7;
        gc.insets = new Insets(0, 5, 2, 5);
        step2Card.add(emailErrorLabel, gc);
        gc.insets = new Insets(5, 5, 5, 5);

        gc.gridx = 0;
        gc.gridy = 8;
        gc.weightx = 0;
        step2Card.add(new JLabel("Contact"), gc);
        gc.gridx = 1;
        gc.weightx = 1;
        step2Card.add(ctF, gc);

        gc.gridx = 1;
        gc.gridy = 9;
        gc.insets = new Insets(0, 5, 2, 5);
        step2Card.add(phoneErrorLabel, gc);
        gc.insets = new Insets(5, 5, 5, 5);

        emailF.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                String err = ValidationUtils.getEmailError(emailF.getText());
                if (err != null) {
                    emailF.setBackground(new Color(0xFFF0F0));
                    emailErrorLabel.setText("⚠ " + err);
                } else {
                    emailF.setBackground(Color.WHITE);
                    emailErrorLabel.setText(" ");
                }
            }

            public void focusGained(FocusEvent e) {
                emailErrorLabel.setText(" ");
                emailF.setBackground(Color.WHITE);
            }
        });

        ctF.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                String err = ValidationUtils.getPhoneError(ctF.getText());
                if (err != null) {
                    ctF.setBackground(new Color(0xFFF0F0));
                    phoneErrorLabel.setText("⚠ " + err);
                } else {
                    ctF.setBackground(Color.WHITE);
                    phoneErrorLabel.setText(" ");
                }
            }

            public void focusGained(FocusEvent e) {
                phoneErrorLabel.setText(" ");
                ctF.setBackground(Color.WHITE);
            }
        });

        findFlightsBtn.addActionListener(e -> {
            String s = bookSrcF.getText().trim();
            String d = bookDstF.getText().trim();
            String date = bookDateF.getText().trim();
            if (s.isEmpty() || d.isEmpty() || date.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter From, To, and Date to search flights!");
                return;
            }
            flightModel.setRowCount(0);
            try {
                PreparedStatement ps = DBSetup.getConnection().prepareStatement(
                    "SELECT flight_id, airline, source, destination, flight_date, time, price, seats, total_seats " +
                    "FROM flights WHERE source=? AND destination=? AND flight_date=? AND seats > 0"
                );
                ps.setString(1, s);
                ps.setString(2, d);
                ps.setString(3, date);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) loadFlightRow(flightModel, rs);
                if (flightModel.getRowCount() == 0)
                    JOptionPane.showMessageDialog(this, "No available flights for " + s + " → " + d + " on " + date);
                else
                    JOptionPane.showMessageDialog(this, flightModel.getRowCount() + " flight(s) found.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        flightTable.getSelectionModel().addListSelectionListener(ev -> {
            int row = flightTable.getSelectedRow();
            if (row >= 0) {
                fidF.setText(String.valueOf(flightModel.getValueAt(row, 0)));
            }
        });

        loadSeatsBtn.addActionListener(e -> {
            String fidText = fidF.getText().trim();
            if (fidText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter or select a Flight ID first!");
                return;
            }
            try {
                int fid = Integer.parseInt(fidText);
                Connection con = DBSetup.getConnection();

                PreparedStatement flightPs = con.prepareStatement(
                        "SELECT seats, total_seats FROM flights WHERE flight_id=?");
                flightPs.setInt(1, fid);
                ResultSet flightRs = flightPs.executeQuery();
                if (!flightRs.next()) {
                    JOptionPane.showMessageDialog(this, "Flight " + fid + " not found!");
                    return;
                }
                int remainingSeats = flightRs.getInt("seats");
                int totalSeats = flightRs.getInt("total_seats");
                if (remainingSeats <= 0) {
                    JOptionPane.showMessageDialog(this, "No available seats on Flight " + fid + "!");
                    seatCombo.removeAllItems();
                    seatCombo.setEnabled(false);
                    return;
                }

                PreparedStatement bookedPs = con.prepareStatement(
                        "SELECT seat_number FROM bookings WHERE flight_id=?");
                bookedPs.setInt(1, fid);
                ResultSet bookedRs = bookedPs.executeQuery();
                java.util.Set<String> bookedSeats = new java.util.HashSet<>();
                while (bookedRs.next()) {
                    String s = bookedRs.getString("seat_number");
                    if (s != null) bookedSeats.add(s);
                }

                seatCombo.removeAllItems();
                String[] seatCols = {"A", "B", "C", "D", "E", "F"};
                int added = 0;
                outer:
                for (int rowNum = 1; rowNum <= (int) Math.ceil(totalSeats / 6.0) + 1; rowNum++) {
                    for (String col : seatCols) {
                        String seat = col + rowNum;
                        if (!bookedSeats.contains(seat)) {
                            seatCombo.addItem(seat);
                            if (++added >= remainingSeats) break outer;
                        }
                    }
                }
                seatCombo.setEnabled(true);

                ResultSet bidRs = con.createStatement().executeQuery(
                        "SELECT AUTO_INCREMENT FROM information_schema.TABLES " +
                        "WHERE TABLE_SCHEMA = 'airline_db' AND TABLE_NAME = 'bookings'");
                int nextBid = bidRs.next() ? bidRs.getInt(1) : 1;
                bidLabel.setText("≈ BID-" + nextBid + "  (assigned on booking)");

                PreparedStatement usedPidPs = con.prepareStatement(
                        "SELECT passenger_id FROM passengers WHERE flight_id=? ORDER BY passenger_id");
                usedPidPs.setInt(1, fid);
                ResultSet usedPidRs = usedPidPs.executeQuery();
                java.util.Set<Integer> usedPids = new java.util.HashSet<>();
                while (usedPidRs.next()) usedPids.add(usedPidRs.getInt(1));

                int nextPid = -1;
                for (int p = 1; p <= totalSeats; p++) {
                    if (!usedPids.contains(p)) {
                        nextPid = p;
                        break;
                    }
                }
                if (nextPid == -1) {
                    JOptionPane.showMessageDialog(this, "All passenger slots for this flight are filled!");
                    return;
                }

                pidLabel.setText("PID-" + nextPid + "  (range: 1–" + totalSeats + " for Flight " + fid + ")");
                pidLabel.putClientProperty("value", nextPid);
                pidLabel.putClientProperty("fid", fid);

                JOptionPane.showMessageDialog(this,
                        remainingSeats + " seat(s) available · Your Passenger ID will be " +
                        nextPid + " (out of " + totalSeats + " slots for Flight " + fid + ")");

            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "Flight ID must be a number!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        JButton bookBtn = new JButton("Confirm Booking");
        JButton clearBtn = new JButton("Clear");

        bookBtn.addActionListener(e -> {
            try {
                Object pidProp = pidLabel.getClientProperty("value");
                Object fidProp = pidLabel.getClientProperty("fid");
                if (pidProp == null || fidProp == null) {
                    JOptionPane.showMessageDialog(this, "Search flights above, select a Flight ID, then click 'Load Seats'!");
                    return;
                }
                int pid = (int) pidProp;
                int fid = (int) fidProp;
                String seat = (String) seatCombo.getSelectedItem();
                String nm = nameF.getText().trim();
                String em = emailF.getText().trim();
                String ct = ctF.getText().trim();

                if (seat == null || seat.isEmpty()) throw new Exception("No seat selected!");
                if (nm.isEmpty()) throw new Exception("Passenger name is required!");

                String emailErr = ValidationUtils.getEmailError(em);
                if (emailErr != null) {
                    emailF.setBackground(new Color(0xFFF0F0));
                    emailErrorLabel.setText("⚠ " + emailErr);
                    emailF.requestFocus();
                    throw new Exception(emailErr);
                }
                String phoneErr = ValidationUtils.getPhoneError(ct);
                if (phoneErr != null) {
                    ctF.setBackground(new Color(0xFFF0F0));
                    phoneErrorLabel.setText("⚠ " + phoneErr);
                    ctF.requestFocus();
                    throw new Exception(phoneErr);
                }

                Connection con = DBSetup.getConnection();

                PreparedStatement seatChk = con.prepareStatement(
                        "SELECT COUNT(*) FROM bookings WHERE flight_id=? AND seat_number=?");
                seatChk.setInt(1, fid);
                seatChk.setString(2, seat);
                ResultSet seatRs = seatChk.executeQuery();
                if (seatRs.next() && seatRs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this, "Seat " + seat + " just taken! Reload seats.");
                    return;
                }

                PreparedStatement pidChk = con.prepareStatement(
                        "SELECT COUNT(*) FROM passengers WHERE flight_id=? AND passenger_id=?");
                pidChk.setInt(1, fid);
                pidChk.setInt(2, pid);
                ResultSet pidRs2 = pidChk.executeQuery();
                if (pidRs2.next() && pidRs2.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this, "Passenger slot just filled — reload seats!");
                    return;
                }

                PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO bookings(flight_id, passenger_name, username, seat_number) VALUES(?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1, fid);
                ps.setString(2, nm);
                ps.setString(3, currentUser);
                ps.setString(4, seat);
                ps.executeUpdate();
                ResultSet genKeys = ps.getGeneratedKeys();
                int assignedBid = genKeys.next() ? genKeys.getInt(1) : -1;

                PreparedStatement ps2 = con.prepareStatement(
                        "INSERT INTO passengers(passenger_id, flight_id, name, email, contact) VALUES(?,?,?,?,?)");
                ps2.setInt(1, pid);
                ps2.setInt(2, fid);
                ps2.setString(3, nm);
                ps2.setString(4, em);
                ps2.setString(5, ct);
                ps2.executeUpdate();

                PreparedStatement upd = con.prepareStatement(
                        "UPDATE flights SET seats=seats-1 WHERE flight_id=?");
                upd.setInt(1, fid);
                upd.executeUpdate();

                new BookingFileHandler("Booking:" + assignedBid + "|Flight:" + fid +
                        "|User:" + currentUser + "|Seat:" + seat).start();
                new PassengerFileHandler("Passenger:" + pid + "|Flight:" + fid +
                        "|Name:" + nm + "|Email:" + em).start();

                JOptionPane.showMessageDialog(this,
                        "Booking Confirmed!  Booking ID: " + assignedBid +
                        "  |  Passenger ID: " + pid + "  |  Seat: " + seat);

                bookSrcF.setText("");
                bookDstF.setText("");
                bookDateF.setText("");
                flightModel.setRowCount(0);
                fidF.setText("");
                nameF.setText("");
                emailF.setText("");
                ctF.setText("");
                seatCombo.removeAllItems();
                seatCombo.setEnabled(false);
                bidLabel.setText("(auto-assigned on booking)");
                pidLabel.setText("(auto — scoped to flight)");
                pidLabel.putClientProperty("value", null);
                pidLabel.putClientProperty("fid", null);
                emailErrorLabel.setText(" ");
                phoneErrorLabel.setText(" ");
                emailF.setBackground(Color.WHITE);
                ctF.setBackground(Color.WHITE);

            } catch (SQLIntegrityConstraintViolationException ex) {
                JOptionPane.showMessageDialog(this, "Conflict — reload seats and try again!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        clearBtn.addActionListener(e -> {
            bookSrcF.setText("");
            bookDstF.setText("");
            bookDateF.setText("");
            flightModel.setRowCount(0);
            fidF.setText("");
            nameF.setText("");
            emailF.setText("");
            ctF.setText("");
            seatCombo.removeAllItems();
            seatCombo.setEnabled(false);
            bidLabel.setText("(auto-assigned on booking)");
            pidLabel.setText("(auto — scoped to flight)");
            pidLabel.putClientProperty("value", null);
            pidLabel.putClientProperty("fid", null);
            emailErrorLabel.setText(" ");
            phoneErrorLabel.setText(" ");
            emailF.setBackground(Color.WHITE);
            ctF.setBackground(Color.WHITE);
        });

        JPanel btnRow = new JPanel(new GridLayout(1, 2, 10, 0));
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new EmptyBorder(10, 0, 0, 0));
        btnRow.add(bookBtn);
        btnRow.add(clearBtn);

        JPanel formsPanel = new JPanel(new BorderLayout(0, 10));
        formsPanel.setBackground(Color.WHITE);
        formsPanel.add(step1Card, BorderLayout.NORTH);
        formsPanel.add(step2Card, BorderLayout.CENTER);

        panel.add(formsPanel, BorderLayout.CENTER);
        panel.add(btnRow, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel cancelTab() {
        JPanel panel = new JPanel(new BorderLayout(0, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 40, 20, 40));

        JPanel card = new JPanel(new BorderLayout(0, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                new EmptyBorder(20, 20, 20, 20)));

        JLabel hint = new JLabel("Enter your Booking ID to cancel the ticket.");
        hint.setFont(new Font("Dialog", Font.PLAIN, 11));

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        row.setBackground(Color.WHITE);
        row.add(new JLabel("Booking ID:"));
        JTextField bidF = new JTextField(10);
        JButton cancelBtn = new JButton("Cancel Ticket");
        row.add(bidF);
        row.add(cancelBtn);

        cancelBtn.addActionListener(e -> {
            try {
                int bid = Integer.parseInt(bidF.getText().trim());
                Connection con = DBSetup.getConnection();
                PreparedStatement chk = con.prepareStatement(
                        "SELECT flight_id, passenger_name, username FROM bookings WHERE booking_id=?");
                chk.setInt(1, bid);
                ResultSet rs = chk.executeQuery();
                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this, "Booking not found!");
                    return;
                }
                if (!rs.getString("username").equals(currentUser)) {
                    JOptionPane.showMessageDialog(this, "This booking does not belong to you!");
                    return;
                }
                int fid = rs.getInt("flight_id");
                String nm = rs.getString("passenger_name");
                if (JOptionPane.showConfirmDialog(this,
                        "Cancel booking #" + bid + " for " + nm + "?",
                        "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;

                PreparedStatement delB = con.prepareStatement(
                        "DELETE FROM bookings WHERE booking_id=?");
                delB.setInt(1, bid);
                delB.executeUpdate();

                PreparedStatement delP = con.prepareStatement(
                        "DELETE FROM passengers WHERE name=? AND flight_id=?");
                delP.setString(1, nm);
                delP.setInt(2, fid);
                delP.executeUpdate();

                PreparedStatement upd = con.prepareStatement(
                        "UPDATE flights SET seats=seats+1 WHERE flight_id=?");
                upd.setInt(1, fid);
                upd.executeUpdate();

                BookingFileHandler.deleteBooking(bid);
                JOptionPane.showMessageDialog(this, "Booking #" + bid + " cancelled successfully!");
                bidF.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        card.add(hint, BorderLayout.NORTH);
        card.add(row, BorderLayout.CENTER);
        panel.add(card, BorderLayout.NORTH);
        return panel;
    }

    private JPanel myBookingsTab() {
        JPanel panel = pagePanel();

        String[] cols = {
            "Booking ID", "Flight ID", "Airline", "Source", "Destination",
            "Date", "Time", "Passenger ID", "Passenger Name",
            "Email", "Contact", "Seat", "Booked At"
        };
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(model);
        table.setFont(new Font("Dialog", Font.PLAIN, 11));
        table.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 11));

        JButton refresh = new JButton("Refresh My Bookings");
        Runnable load = () -> {
            model.setRowCount(0);
            try {
                PreparedStatement ps = DBSetup.getConnection().prepareStatement(
                    "SELECT b.booking_id, b.flight_id, " +
                    "       f.airline, f.source, f.destination, f.flight_date, f.time, " +
                    "       p.passenger_id, p.name, p.email, p.contact, " +
                    "       b.seat_number, b.booked_at " +
                    "FROM bookings b " +
                    "LEFT JOIN flights    f ON b.flight_id      = f.flight_id " +
                    "LEFT JOIN passengers p ON b.passenger_name = p.name " +
                    "                      AND b.flight_id      = p.flight_id " +
                    "WHERE b.username = ? " +
                    "ORDER BY b.booked_at ASC"
                );
                ps.setString(1, currentUser);
                ResultSet rs = ps.executeQuery();
                while (rs.next())
                    model.addRow(new Object[]{
                            rs.getInt("booking_id"),
                            rs.getInt("flight_id"),
                            rs.getString("airline") != null ? rs.getString("airline") : "—",
                            rs.getString("source") != null ? rs.getString("source") : "—",
                            rs.getString("destination") != null ? rs.getString("destination") : "—",
                            rs.getString("flight_date") != null ? rs.getString("flight_date") : "—",
                            rs.getString("time") != null ? rs.getString("time") : "—",
                            rs.getInt("passenger_id") != 0 ? rs.getInt("passenger_id") : "—",
                            rs.getString("name") != null ? rs.getString("name") : "—",
                            rs.getString("email") != null ? rs.getString("email") : "—",
                            rs.getString("contact") != null ? rs.getString("contact") : "—",
                            rs.getString("seat_number") != null ? rs.getString("seat_number") : "—",
                            rs.getTimestamp("booked_at")
                    });
                if (model.getRowCount() == 0)
                    model.addRow(new Object[]{
                        "—", "—", "—", "—", "—", "—", "—", "—", "No bookings found", "—", "—", "—", "—"
                    });
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        };
        refresh.addActionListener(e -> load.run());
        load.run();

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new EmptyBorder(0, 0, 10, 0));
        btnRow.add(refresh);

        panel.add(btnRow, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }
}