package airline.gui;

import airline.db.DBSetup;
import airline.utils.BookingFileHandler;
import airline.utils.FlightFileHandler;
import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class AdminDashboard extends JFrame {

    public AdminDashboard() {
        setTitle("SkyLine — Admin Dashboard");
        setSize(1200, 720);
        setMinimumSize(new Dimension(1000, 600));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        initUI();
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);
        root.add(buildTopBar(), BorderLayout.NORTH);
        root.add(buildTabs(), BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Color.LIGHT_GRAY);
        bar.setBorder(new EmptyBorder(10, 20, 10, 20));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        JLabel icon = new JLabel("✈");
        icon.setFont(new Font("Dialog", Font.BOLD, 20));
        JLabel name = new JLabel("SkyLine");
        name.setFont(new Font("Dialog", Font.BOLD, 18));
        JLabel sep = new JLabel("·");
        JLabel tag = new JLabel("Admin Dashboard");
        left.add(icon);
        left.add(name);
        left.add(sep);
        left.add(tag);

        JButton logout = new JButton("Logout");
        bar.add(left, BorderLayout.WEST);
        bar.add(logout, BorderLayout.EAST);
        logout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
        return bar;
    }

    private JTabbedPane buildTabs() {
        JTabbedPane tabs = new JTabbedPane(JTabbedPane.TOP);
        tabs.setFont(new Font("Dialog", Font.PLAIN, 12));
        tabs.addTab("Flights", flightsTab());
        tabs.addTab("Bookings", bookingsTab());
        tabs.addTab("Passengers", passengersTab());
        tabs.addTab("Reports", reportsTab());
        return tabs;
    }

    private JPanel pagePanel() {
        JPanel p = new JPanel(new BorderLayout(0, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(15, 15, 15, 15));
        return p;
    }

    private JPanel flightsTab() {
        JPanel panel = pagePanel();

        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            new EmptyBorder(15, 15, 15, 15)
        ));

        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(5, 5, 5, 5);
        gc.fill = GridBagConstraints.HORIZONTAL;

        JTextField idF = new JTextField(12);
        JTextField airlineF = new JTextField(12);
        JTextField srcF = new JTextField(12);
        JTextField dstF = new JTextField(12);
        JTextField dateF = new JTextField(12);
        JTextField timeF = new JTextField(12);
        JTextField priceF = new JTextField(12);
        JTextField seatsF = new JTextField(12);
        JTextField totalF = new JTextField(12);

        String[] labels = {
            "Flight ID", "Airline", "Source", "Destination",
            "Date (YYYY-MM-DD)", "Time (HH:MM)", "Price (₹)",
            "Available Seats", "Total Seats"
        };
        JTextField[] flds = {idF, airlineF, srcF, dstF, dateF, timeF, priceF, seatsF, totalF};

        for (int i = 0; i < labels.length; i++) {
            int col = (i % 3) * 2;
            int row = i / 3;
            gc.gridx = col;
            gc.gridy = row;
            gc.weightx = 0;
            card.add(new JLabel(labels[i]), gc);
            gc.gridx = col + 1;
            gc.weightx = 1;
            card.add(flds[i], gc);
        }

        String[] cols = {
            "Flight ID", "Airline", "Source", "Destination",
            "Date", "Time", "Price (₹)", "Avail. Seats", "Total Seats"
        };
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable table = new JTable(model);
        table.setFont(new Font("Dialog", Font.PLAIN, 11));
        table.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 11));

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        btnRow.setBackground(Color.WHITE);
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update Price");
        JButton deleteBtn = new JButton("Delete");
        JButton refreshBtn = new JButton("Refresh");
        JButton clearBtn = new JButton("Clear");
        for (JButton b : new JButton[]{addBtn, updateBtn, deleteBtn, refreshBtn, clearBtn})
            btnRow.add(b);

        Runnable load = () -> {
            model.setRowCount(0);
            try {
                ResultSet rs = DBSetup.getConnection().createStatement()
                    .executeQuery(
                        "SELECT flight_id, airline, source, destination, flight_date, " +
                        "time, price, seats, total_seats FROM flights"
                    );
                while (rs.next())
                    model.addRow(new Object[]{
                        rs.getInt(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6),
                        "₹" + rs.getDouble(7), rs.getInt(8), rs.getInt(9)
                    });
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        };

        refreshBtn.addActionListener(e -> load.run());
        clearBtn.addActionListener(e -> {
            for (JTextField f : flds)
                f.setText("");
        });

        addBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idF.getText().trim());
                String airline = airlineF.getText().trim();
                String src = srcF.getText().trim();
                String dst = dstF.getText().trim();
                String date = dateF.getText().trim();
                String tim = timeF.getText().trim();
                double prc = Double.parseDouble(priceF.getText().trim());
                int seats = Integer.parseInt(seatsF.getText().trim());
                int total = Integer.parseInt(totalF.getText().trim());

                if (airline.isEmpty() || src.isEmpty() || dst.isEmpty() || date.isEmpty() || tim.isEmpty())
                    throw new Exception("All fields are required!");
                if (seats > total)
                    throw new Exception("Available seats cannot exceed Total Seats!");

                PreparedStatement ps = DBSetup.getConnection().prepareStatement(
                    "INSERT INTO flights(flight_id, airline, source, destination, flight_date, " +
                    "time, price, seats, total_seats) VALUES(?,?,?,?,?,?,?,?,?)");
                ps.setInt(1, id);
                ps.setString(2, airline);
                ps.setString(3, src);
                ps.setString(4, dst);
                ps.setString(5, date);
                ps.setString(6, tim);
                ps.setDouble(7, prc);
                ps.setInt(8, seats);
                ps.setInt(9, total);
                ps.executeUpdate();

                new FlightFileHandler(
                    "ID:" + id + "|Airline:" + airline + "|Src:" + src + "|Dst:" + dst +
                    "|Date:" + date + "|T:" + tim + "|P:" + prc + "|S:" + seats + "|TS:" + total
                ).start();
                JOptionPane.showMessageDialog(panel, "Flight Added!");
                load.run();
                for (JTextField f : flds)
                    f.setText("");
            } catch (SQLIntegrityConstraintViolationException ex) {
                JOptionPane.showMessageDialog(panel, "Flight ID already exists!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        });

        updateBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idF.getText().trim());
                double prc = Double.parseDouble(priceF.getText().trim());
                PreparedStatement ps = DBSetup.getConnection()
                    .prepareStatement("UPDATE flights SET price=? WHERE flight_id=?");
                ps.setDouble(1, prc);
                ps.setInt(2, id);
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(panel, "Price Updated!");
                    load.run();
                } else
                    JOptionPane.showMessageDialog(panel, "Flight ID not found!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        });

        deleteBtn.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idF.getText().trim());
                if (JOptionPane.showConfirmDialog(panel, "Delete Flight " + id + "?", "Confirm",
                    JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION)
                    return;
                PreparedStatement ps = DBSetup.getConnection()
                    .prepareStatement("DELETE FROM flights WHERE flight_id=?");
                ps.setInt(1, id);
                if (ps.executeUpdate() > 0) {
                    FlightFileHandler.deleteFlight(id);
                    JOptionPane.showMessageDialog(panel, "Flight Deleted!");
                    load.run();
                } else
                    JOptionPane.showMessageDialog(panel, "Flight not found!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        });

        table.getSelectionModel().addListSelectionListener(ev -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                idF.setText(String.valueOf(model.getValueAt(row, 0)));
                airlineF.setText(String.valueOf(model.getValueAt(row, 1)));
                srcF.setText(String.valueOf(model.getValueAt(row, 2)));
                dstF.setText(String.valueOf(model.getValueAt(row, 3)));
                dateF.setText(String.valueOf(model.getValueAt(row, 4)));
                timeF.setText(String.valueOf(model.getValueAt(row, 5)));
                priceF.setText(String.valueOf(model.getValueAt(row, 6)).replace("₹", ""));
                seatsF.setText(String.valueOf(model.getValueAt(row, 7)));
                totalF.setText(String.valueOf(model.getValueAt(row, 8)));
            }
        });
        load.run();

        panel.add(card, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        panel.add(btnRow, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel bookingsTab() {
        JPanel panel = pagePanel();

        String[] cols = {
            "Booking ID", "Flight ID", "Airline", "Source", "Destination",
            "Date", "Time", "Passenger Name", "Username", "Passenger ID", "Seat", "Booked At"
        };
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable table = new JTable(model);
        table.setFont(new Font("Dialog", Font.PLAIN, 11));
        table.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 11));

        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        topRow.setBackground(Color.WHITE);
        topRow.setBorder(new EmptyBorder(0, 0, 10, 0));
        topRow.add(new JLabel("Booking ID:"));
        JTextField bidF = new JTextField(10);
        JButton cancelBtn = new JButton("Cancel Booking");
        JButton refreshBtn = new JButton("Refresh");
        topRow.add(bidF);
        topRow.add(cancelBtn);
        topRow.add(refreshBtn);

        Runnable load = () -> {
            model.setRowCount(0);
            try {
                ResultSet rs = DBSetup.getConnection().createStatement()
                    .executeQuery(
                        "SELECT b.booking_id, b.flight_id, " +
                        "f.airline, f.source, f.destination, f.flight_date, f.time, " +
                        "b.passenger_name, b.username, " +
                        "p.passenger_id, b.seat_number, b.booked_at " +
                        "FROM bookings b " +
                        "LEFT JOIN flights f ON b.flight_id = f.flight_id " +
                        "LEFT JOIN passengers p ON p.name = b.passenger_name AND p.flight_id = b.flight_id " +
                        "ORDER BY b.booked_at ASC"
                    );
                while (rs.next())
                    model.addRow(new Object[]{
                        rs.getInt(1), rs.getInt(2),
                        rs.getString(3) != null ? rs.getString(3) : "—",
                        rs.getString(4) != null ? rs.getString(4) : "—",
                        rs.getString(5) != null ? rs.getString(5) : "—",
                        rs.getString(6) != null ? rs.getString(6) : "—",
                        rs.getString(7) != null ? rs.getString(7) : "—",
                        rs.getString(8), rs.getString(9),
                        rs.getInt(10) != 0 ? rs.getInt(10) : "—",
                        rs.getString(11) != null ? rs.getString(11) : "—",
                        rs.getTimestamp(12)
                    });
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        };

        refreshBtn.addActionListener(e -> load.run());

        cancelBtn.addActionListener(e -> {
            try {
                int bid = Integer.parseInt(bidF.getText().trim());
                if (JOptionPane.showConfirmDialog(panel, "Cancel Booking #" + bid + "?", "Confirm",
                    JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION)
                    return;
                Connection con = DBSetup.getConnection();
                PreparedStatement get = con.prepareStatement(
                    "SELECT flight_id, passenger_name FROM bookings WHERE booking_id=?");
                get.setInt(1, bid);
                ResultSet rs = get.executeQuery();
                if (rs.next()) {
                    int fid = rs.getInt("flight_id");
                    String nm = rs.getString("passenger_name");

                    PreparedStatement delB = con.prepareStatement(
                        "DELETE FROM bookings WHERE booking_id=?");
                    delB.setInt(1, bid);
                    delB.executeUpdate();

                    PreparedStatement delP = con.prepareStatement(
                        "DELETE FROM passengers WHERE name=? AND flight_id=?");
                    delP.setString(1, nm);
                    delP.setInt(2, fid);
                    delP.executeUpdate();

                    PreparedStatement upd = con.prepareStatement(
                        "UPDATE flights SET seats=seats+1 WHERE flight_id=?");
                    upd.setInt(1, fid);
                    upd.executeUpdate();

                    BookingFileHandler.deleteBooking(bid);
                    JOptionPane.showMessageDialog(panel, "Booking #" + bid + " Cancelled!");
                    load.run();
                } else {
                    JOptionPane.showMessageDialog(panel, "Booking ID not found!");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        });

        table.getSelectionModel().addListSelectionListener(ev -> {
            int row = table.getSelectedRow();
            if (row >= 0)
                bidF.setText(String.valueOf(model.getValueAt(row, 0)));
        });
        load.run();

        panel.add(topRow, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel passengersTab() {
        JPanel panel = pagePanel();

        String[] cols = {
            "DB ID", "Passenger ID", "Flight ID", "Airline",
            "Source", "Destination", "Date", "Name", "Email", "Contact"
        };
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        JTable table = new JTable(model);
        table.setFont(new Font("Dialog", Font.PLAIN, 11));
        table.getTableHeader().setFont(new Font("Dialog", Font.BOLD, 11));

        JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        topRow.setBackground(Color.WHITE);
        topRow.setBorder(new EmptyBorder(0, 0, 10, 0));
        topRow.add(new JLabel("Search Name:"));
        JTextField searchF = new JTextField(15);
        JButton searchBtn = new JButton("Search");
        JButton showAllBtn = new JButton("Show All");
        topRow.add(searchF);
        topRow.add(searchBtn);
        topRow.add(showAllBtn);

        String baseQuery =
            "SELECT p.id, p.passenger_id, p.flight_id, " +
            "f.airline, f.source, f.destination, f.flight_date, " +
            "p.name, p.email, p.contact " +
            "FROM passengers p " +
            "LEFT JOIN flights f ON p.flight_id = f.flight_id " +
            "ORDER BY p.flight_id, p.passenger_id";

        Runnable loadAll = () -> {
            model.setRowCount(0);
            try {
                ResultSet rs = DBSetup.getConnection().createStatement().executeQuery(baseQuery);
                while (rs.next())
                    model.addRow(new Object[]{
                        rs.getInt(1), rs.getInt(2), rs.getInt(3),
                        rs.getString(4) != null ? rs.getString(4) : "—",
                        rs.getString(5) != null ? rs.getString(5) : "—",
                        rs.getString(6) != null ? rs.getString(6) : "—",
                        rs.getString(7) != null ? rs.getString(7) : "—",
                        rs.getString(8), rs.getString(9), rs.getString(10)
                    });
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        };

        showAllBtn.addActionListener(e -> {
            searchF.setText("");
            loadAll.run();
        });
        searchBtn.addActionListener(e -> {
            String nm = searchF.getText().trim();
            if (nm.isEmpty()) {
                loadAll.run();
                return;
            }
            model.setRowCount(0);
            try {
                PreparedStatement ps = DBSetup.getConnection().prepareStatement(
                    "SELECT p.id, p.passenger_id, p.flight_id, " +
                    "f.airline, f.source, f.destination, f.flight_date, " +
                    "p.name, p.email, p.contact " +
                    "FROM passengers p " +
                    "LEFT JOIN flights f ON p.flight_id = f.flight_id " +
                    "WHERE p.name = ?"
                );
                ps.setString(1, nm);
                ResultSet rs = ps.executeQuery();
                while (rs.next())
                    model.addRow(new Object[]{
                        rs.getInt(1), rs.getInt(2), rs.getInt(3),
                        rs.getString(4) != null ? rs.getString(4) : "—",
                        rs.getString(5) != null ? rs.getString(5) : "—",
                        rs.getString(6) != null ? rs.getString(6) : "—",
                        rs.getString(7) != null ? rs.getString(7) : "—",
                        rs.getString(8), rs.getString(9), rs.getString(10)
                    });
                if (model.getRowCount() == 0)
                    JOptionPane.showMessageDialog(panel, "No passenger found: " + nm);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        });
        loadAll.run();

        panel.add(topRow, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel reportsTab() {
        JPanel panel = new JPanel(new BorderLayout(0, 15));
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JPanel grid = new JPanel(new GridLayout(2, 3, 10, 10));
        grid.setBackground(Color.WHITE);

        String[] titles = {"Total Flights", "Total Bookings", "Total Passengers",
            "Total Users", "Available Seats", ""};
        String[] queries = {
            "SELECT COUNT(*) FROM flights",
            "SELECT COUNT(*) FROM bookings",
            "SELECT COUNT(*) FROM passengers",
            "SELECT COUNT(*) FROM users",
            "SELECT COALESCE(SUM(seats),0) FROM flights",
            null
        };
        JLabel[] vals = new JLabel[5];

        for (int i = 0; i < 6; i++) {
            if (i == 5) {
                JPanel ph = new JPanel();
                ph.setOpaque(false);
                grid.add(ph);
                continue;
            }
            JPanel card = new JPanel(new BorderLayout());
            card.setBackground(Color.WHITE);
            card.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
            
            JLabel titleLbl = new JLabel(titles[i]);
            titleLbl.setFont(new Font("Dialog", Font.PLAIN, 12));
            titleLbl.setHorizontalAlignment(SwingConstants.CENTER);
            
            vals[i] = new JLabel("—");
            vals[i].setFont(new Font("Dialog", Font.BOLD, 28));
            vals[i].setHorizontalAlignment(SwingConstants.CENTER);
            
            card.add(titleLbl, BorderLayout.NORTH);
            card.add(vals[i], BorderLayout.CENTER);
            card.setBorder(new EmptyBorder(15, 15, 15, 15));
            
            grid.add(card);
        }

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        bottom.setBackground(Color.WHITE);
        JButton refresh = new JButton("Refresh Stats");
        refresh.addActionListener(e -> {
            try {
                Connection con = DBSetup.getConnection();
                for (int i = 0; i < queries.length - 1; i++) {
                    ResultSet rs = con.createStatement().executeQuery(queries[i]);
                    if (rs.next())
                        vals[i].setText(String.valueOf(rs.getInt(1)));
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(panel, ex.getMessage());
            }
        });
        bottom.add(refresh);
        refresh.doClick();

        panel.add(grid, BorderLayout.CENTER);
        panel.add(bottom, BorderLayout.SOUTH);
        return panel;
    }
}