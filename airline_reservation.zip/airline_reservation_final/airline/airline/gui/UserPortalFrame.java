package airline.gui;

import airline.db.DBSetup;
import airline.utils.UserFileHandler;
import airline.utils.ValidationUtils;
import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;

public class UserPortalFrame extends JFrame {

    private JTabbedPane tabs;

    public UserPortalFrame() {
        setTitle("SkyLine — User Portal");
        setSize(480, 580);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        initUI();
    }

    private void initUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);

        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(Color.LIGHT_GRAY);
        bar.setBorder(new EmptyBorder(10, 20, 10, 20));
        bar.add(new JLabel("User Portal"), BorderLayout.WEST);
        
        JButton back = new JButton("Back");
        back.addActionListener(e -> { 
            dispose(); 
            new LoginFrame().setVisible(true); 
        });
        bar.add(back, BorderLayout.EAST);

        tabs = new JTabbedPane();
        tabs.setFont(new Font("Dialog", Font.PLAIN, 12));
        tabs.addTab("Register", buildRegisterTab());
        tabs.addTab("Login", buildLoginTab());

        root.add(bar, BorderLayout.NORTH);
        root.add(tabs, BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel buildRegisterTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(20, 30, 20, 30));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1;
        gc.gridx = 0;

        JTextField uF = new JTextField(15);
        JPasswordField pF = new JPasswordField(15);
        JTextField eF = new JTextField(15);
        JTextField cF = new JTextField(15);

        JLabel uErr = errorLabel();
        JLabel pErr = errorLabel();
        JLabel eErr = errorLabel();
        JLabel cErr = errorLabel();

        JLabel pHint = hintLabel("Min 6 characters and at least one digit (e.g. pass123)");
        JLabel eHint = hintLabel("Enter a valid email (e.g. user@example.com)");
        JLabel cHint = hintLabel("10-digit Indian mobile number (e.g. 9876543210)");

        String[] lbs = {"Username", "Password", "Email", "Contact Number"};
        JComponent[] flds = {uF, pF, eF, cF};
        JLabel[] hints = {null, pHint, eHint, cHint};
        JLabel[] errs = {uErr, pErr, eErr, cErr};

        for (int i = 0; i < lbs.length; i++) {
            gc.gridy = i * 4;
            gc.insets = new Insets(i == 0 ? 0 : 8, 0, 3, 0);
            JLabel label = new JLabel(lbs[i]);
            label.setFont(new Font("Dialog", Font.PLAIN, 11));
            label.setForeground(Color.DARK_GRAY);
            form.add(label, gc);

            gc.gridy = i * 4 + 1;
            gc.insets = new Insets(0, 0, 2, 0);
            form.add(flds[i], gc);

            gc.gridy = i * 4 + 2;
            gc.insets = new Insets(1, 2, 0, 0);
            form.add(hints[i] != null ? hints[i] : new JLabel(), gc);

            gc.gridy = i * 4 + 3;
            gc.insets = new Insets(0, 0, 0, 0);
            form.add(errs[i], gc);
        }

        JButton btn = new JButton("Register & Login");
        btn.setFont(new Font("Dialog", Font.BOLD, 13));
        btn.setBackground(Color.LIGHT_GRAY);
        btn.setPreferredSize(new Dimension(0, 46));
        
        btn.addActionListener(e -> {
            String u = uF.getText().trim();
            String p = new String(pF.getPassword()).trim();
            String em = eF.getText().trim();
            String ct = cF.getText().trim();

            boolean okU = u.isEmpty()
                    ? showFieldError(uErr, "Username is required.")
                    : showFieldError(uErr, null);
            boolean okP = validatePassword(p, pErr);
            boolean okE = showFieldError(eErr, ValidationUtils.getEmailError(em));
            boolean okC = showFieldError(cErr, getContactError(ct));

            if (!okU || !okP || !okE || !okC) return;

            try {
                PreparedStatement ps = DBSetup.getConnection()
                        .prepareStatement("INSERT INTO users VALUES(?,?,?,?)");
                ps.setString(1, u);
                ps.setString(2, p);
                ps.setString(3, em);
                ps.setString(4, ct);
                ps.executeUpdate();
                new UserFileHandler("Username:" + u + "|Email:" + em + "|Contact:" + ct).start();
                JOptionPane.showMessageDialog(this, "Registered! Logging you in...", "Success", JOptionPane.INFORMATION_MESSAGE);
                openDashboard(u);
            } catch (SQLIntegrityConstraintViolationException ex) {
                showFieldError(uErr, "Username already exists!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel btnRow = new JPanel(new BorderLayout());
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new EmptyBorder(14, 0, 0, 0));
        btnRow.add(btn, BorderLayout.CENTER);

        panel.add(form, BorderLayout.CENTER);
        panel.add(btnRow, BorderLayout.SOUTH);
        return panel;
    }

    private JPanel buildLoginTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.GRAY, 1),
            new EmptyBorder(20, 20, 20, 20)
        ));

        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1;
        gc.gridx = 0;

        JTextField uF = new JTextField(15);
        JPasswordField pF = new JPasswordField(15);

        JLabel uErr = errorLabel();
        JLabel pErr = errorLabel();

        gc.gridy = 0;
        gc.insets = new Insets(0, 0, 3, 0);
        JLabel userLabel = new JLabel("Username");
        userLabel.setFont(new Font("Dialog", Font.PLAIN, 11));
        userLabel.setForeground(Color.DARK_GRAY);
        form.add(userLabel, gc);
        
        gc.gridy = 1;
        gc.insets = new Insets(0, 0, 2, 0);
        form.add(uF, gc);
        
        gc.gridy = 2;
        gc.insets = new Insets(0, 0, 10, 0);
        form.add(uErr, gc);

        gc.gridy = 3;
        gc.insets = new Insets(0, 0, 3, 0);
        JLabel passLabel = new JLabel("Password");
        passLabel.setFont(new Font("Dialog", Font.PLAIN, 11));
        passLabel.setForeground(Color.DARK_GRAY);
        form.add(passLabel, gc);
        
        gc.gridy = 4;
        gc.insets = new Insets(0, 0, 2, 0);
        form.add(pF, gc);
        
        gc.gridy = 5;
        gc.insets = new Insets(0, 0, 0, 0);
        form.add(pErr, gc);

        JButton btn = new JButton("Login");
        btn.setFont(new Font("Dialog", Font.BOLD, 13));
        btn.setBackground(Color.LIGHT_GRAY);
        btn.setPreferredSize(new Dimension(0, 46));
        
        btn.addActionListener(e -> {
            String u = uF.getText().trim();
            String p = new String(pF.getPassword()).trim();

            boolean okU = u.isEmpty()
                    ? showFieldError(uErr, "Username is required.")
                    : showFieldError(uErr, null);
            boolean okP = validatePassword(p, pErr);
            if (!okU || !okP) return;

            try {
                PreparedStatement ps = DBSetup.getConnection()
                        .prepareStatement("SELECT * FROM users WHERE username=? AND password=?");
                ps.setString(1, u);
                ps.setString(2, p);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    JOptionPane.showMessageDialog(this, "Welcome back, " + u + "!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    openDashboard(u);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
                    pF.setText("");
                    showFieldError(pErr, "Incorrect username or password.");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel btnRow = new JPanel(new BorderLayout());
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new EmptyBorder(14, 0, 0, 0));
        btnRow.add(btn, BorderLayout.CENTER);

        panel.add(form, BorderLayout.CENTER);
        panel.add(btnRow, BorderLayout.SOUTH);
        return panel;
    }

    private boolean validatePassword(String p, JLabel errLabel) {
        if (p.isEmpty()) return showFieldError(errLabel, "Password is required.");
        if (p.length() < 6) return showFieldError(errLabel, "Password must be at least 6 characters.");
        if (!p.matches(".*\\d.*"))
            return showFieldError(errLabel, "Password must contain at least one digit.");
        return showFieldError(errLabel, null);
    }

    private String getContactError(String phone) {
        if (phone == null || phone.trim().isEmpty()) return "Contact number is required.";
        String digits = phone.trim().replaceAll("\\D", "");
        if (digits.length() != 10) return "Contact number must be exactly 10 digits.";
        return null;
    }

    private boolean showFieldError(JLabel label, String msg) {
        if (msg == null) {
            label.setText(" ");
            label.setVisible(false);
            return true;
        } else {
            label.setText("⚠ " + msg);
            label.setVisible(true);
            return false;
        }
    }

    private JLabel errorLabel() {
        JLabel lbl = new JLabel(" ");
        lbl.setFont(new Font("Dialog", Font.PLAIN, 10));
        lbl.setForeground(Color.RED);
        lbl.setVisible(false);
        return lbl;
    }

    private JLabel hintLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Dialog", Font.PLAIN, 9));
        lbl.setForeground(Color.GRAY);
        return lbl;
    }

    private void openDashboard(String username) {
        dispose();
        new UserDashboard(username).setVisible(true);
    }
}