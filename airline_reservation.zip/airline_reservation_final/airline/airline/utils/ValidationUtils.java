package airline.utils;

import java.util.regex.Pattern;

public class ValidationUtils {

    // Standard email pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );

    // Indian mobile: optional +91/91/0 prefix, then 10 digits starting with 6-9
    private static final Pattern PHONE_PATTERN = Pattern.compile(
        "^(\\+91|91|0)?[6-9]\\d{9}$"
    );

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        if (phone == null) return false;
        return PHONE_PATTERN.matcher(phone.trim().replaceAll("\\s+", "")).matches();
    }

    public static String getEmailError(String email) {
        if (email == null || email.trim().isEmpty()) return "Email is required.";
        if (!isValidEmail(email)) return "Enter a valid email (e.g. user@example.com).";
        return null;
    }

    public static String getPhoneError(String phone) {
    if (phone == null || phone.trim().isEmpty())
        return "Contact number is required.";

    String cleaned = phone.trim().replaceAll("\\s+", "");

    if (!cleaned.matches("^[6-9]\\d{9}$"))
        return "Enter a valid 10-digit mobile number (e.g. 9876543210).";

    return null;
}
}