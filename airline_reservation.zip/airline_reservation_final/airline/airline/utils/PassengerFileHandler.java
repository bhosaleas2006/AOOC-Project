package airline.utils;

import java.io.*;

public class PassengerFileHandler extends Thread {

    private String data;

    public PassengerFileHandler(String data) { this.data = data; }

    public void run() {
        try {
            FileWriter fw = new FileWriter("passengers.txt", true);
            PrintWriter pw = new PrintWriter(fw);
            pw.println(data);
            pw.close(); fw.close();
        } catch (Exception e) { System.out.println(e); }
    }

    public static void deletePassenger(String name) {
        try {
            File inputFile = new File("passengers.txt");
            File tempFile  = new File("temp.txt");
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.contains("Name: " + name)) pw.println(line);
            }
            br.close(); pw.close();
            inputFile.delete(); tempFile.renameTo(inputFile);
        } catch (Exception e) { System.out.println(e); }
    }
}
