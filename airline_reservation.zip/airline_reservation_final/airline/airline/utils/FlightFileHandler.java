package airline.utils;

import java.io.*;

public class FlightFileHandler extends Thread {

    String data;

    public FlightFileHandler(String data) { this.data = data; }

    public void run() {
        try {
            FileWriter fw = new FileWriter("flights.txt", true);
            fw.write(data + "\n");
            fw.close();
        } catch (Exception e) { System.out.println(e); }
    }

    public static void deleteFlight(int flightId) {
        try {
            File input = new File("flights.txt");
            File temp  = new File("temp.txt");
            BufferedReader br = new BufferedReader(new FileReader(input));
            BufferedWriter bw = new BufferedWriter(new FileWriter(temp));
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.contains("Flight ID: " + flightId)) { bw.write(line); bw.newLine(); }
            }
            br.close(); bw.close();
            input.delete(); temp.renameTo(input);
        } catch (Exception e) { System.out.println(e); }
    }
}
