import airline.db.DBSetup;
import airline.gui.LoginFrame;

public class MainApp {
    public static void main(String[] args) {
        DBSetup.init();
        javax.swing.SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}
